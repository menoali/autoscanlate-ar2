# 🎌 AutoScanlate AR

**مترجم كوميكس ومانغا تلقائي من الإنجليزية إلى العربية**

يستخدم Claude Vision لكشف فقاعات النص وترجمتها، ثم OpenCV لمسح النص الإنجليزي وكتابة العربي مكانه بدقة.

---

## ✨ المميزات

| الميزة | التفاصيل |
|--------|----------|
| 🤖 كشف تلقائي | Claude Vision يحدد كل فقاعة بالبكسل |
| 🗑 مسح ذكي | Contour Detection يمسح شكل الفقاعة كاملاً بما فيه الذيل |
| 📦 CBZ / CBR | دعم كامل لملفات الكوميكس المضغوطة |
| 🖼 Batch | حتى 100 صفحة دفعة واحدة |
| ⚡ متوازي | معالجة عدة صفحات في نفس الوقت |
| 📱 Google Colab | يشتغل من الآيفون بدون تثبيت أي شيء |

---

## 🚀 التشغيل السريع

### على Google Colab (موصى به للآيفون)

1. افتح [AutoScanlate_AR.ipynb](AutoScanlate_AR.ipynb) في Google Colab
2. أدخل مفتاح Anthropic API في الخلية 3
3. ارفع الملف وشغّل

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/YOUR_USERNAME/autoscanlate-ar/blob/main/AutoScanlate_AR.ipynb)

### على الكمبيوتر

```bash
# تثبيت
git clone https://github.com/YOUR_USERNAME/autoscanlate-ar
cd autoscanlate-ar
pip install -r requirements.txt

# ترجمة ملف CBZ
python autoscanlate.py --input chapter.cbz --api_key sk-ant-...

# ترجمة مجلد كامل
python autoscanlate.py --input pages/ --api_key sk-ant-... --workers 4

# ترجمة صورة واحدة
python autoscanlate.py --input page.jpg --api_key sk-ant-...
```

---

## ⚙️ الخيارات

```
--input   / -i   الملف أو المجلد (صورة / CBZ / CBR / ZIP / مجلد)
--output  / -o   مجلد الإخراج (افتراضي: input_ar/)
--api_key / -k   مفتاح Anthropic API
--workers / -w   صفحات متوازية (افتراضي: 4)
--quality / -q   جودة JPEG 1-100 (افتراضي: 92)
--repack  / -r   إعادة تعبئة كـ CBZ (افتراضي: مفعّل)
```

---

## 📋 المتطلبات

```
opencv-python-headless
pillow
rarfile          # لدعم CBR
```

للـ CBR يحتاج أيضاً:
```bash
# Linux/Colab
apt install unrar

# Mac
brew install unrar

# Windows
# حمّل WinRAR أو 7-Zip
```

---

## 🔑 الحصول على مفتاح API

1. روح على [console.anthropic.com](https://console.anthropic.com)
2. سجّل حساب
3. اضغط **API Keys** → **Create Key**

---

## 🏗 كيف يعمل

```
صورة الكوميك
     ↓
Claude Vision يحلل الصورة
     ↓
يُرجع JSON بإحداثيات كل فقاعة + الترجمة
     ↓
لكل فقاعة:
  ├─ dialogue → Contour Detection يمسح الشكل البيضوي كاملاً
  ├─ narration → Plain Inpaint للصناديق المستطيلة
  └─ title → Pure Fill للعناوين
     ↓
يكتب النص العربي في مركز كل فقاعة
     ↓
يحفظ الصورة أو يعيد تعبئتها كـ CBZ
```

---

## 📝 ملاحظات

- كل صفحة تستهلك ~1-3 ثانية API + وقت المعالجة
- 100 صفحة ≈ 3-8 دقائق حسب السرعة
- الـ `--workers 4` مناسب لمعظم الحالات، لا ترفعه كثيراً تجنباً لـ rate limit

---

## 📜 الترخيص

MIT License — للاستخدام الشخصي والتعليمي

مبني على مبادئ [AutoScanlate-AI](https://github.com/P4ST4S/AutoScanlate-AI)
