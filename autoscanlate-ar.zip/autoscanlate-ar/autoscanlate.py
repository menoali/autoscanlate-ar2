#!/usr/bin/env python3
"""
AutoScanlate AR — مترجم كوميكس/مانغا تلقائي
يدعم: صور منفردة, ZIP, CBZ, CBR
الاستخدام:
  python autoscanlate.py --input chapter.cbz --api_key sk-ant-...
  python autoscanlate.py --input pages/ --api_key sk-ant-...
"""

import os, sys, json, base64, zipfile, shutil, time, argparse, re
import urllib.request, urllib.error, http.client
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

# ─── Config ──────────────────────────────────────────────────────────────────
SUPPORTED_IMG = {'.jpg', '.jpeg', '.png', '.webp', '.bmp', '.tiff'}
FONT_CANDIDATES = [
    '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
    '/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf',
    '/usr/local/share/fonts/Tajawal-Bold.ttf',
    'C:/Windows/Fonts/arial.ttf',
    '/System/Library/Fonts/Helvetica.ttc',
]
CLAUDE_MODEL   = 'claude-sonnet-4-20250514'
MAX_TOKENS     = 4096
MAX_WORKERS    = 4   # parallel pages
JPEG_QUALITY   = 92

# ─── Font ────────────────────────────────────────────────────────────────────
def get_font(size: int):
    for p in FONT_CANDIDATES:
        if os.path.exists(p):
            try: return ImageFont.truetype(p, max(8, int(size)))
            except: pass
    return ImageFont.load_default()

# ─── Text wrap ───────────────────────────────────────────────────────────────
def wrap_text(draw, text, font, max_w):
    words = text.split()
    lines, cur = [], ''
    for w in words:
        test = (cur + ' ' + w).strip()
        bb = draw.textbbox((0,0), test, font=font)
        if (bb[2]-bb[0]) > max_w and cur:
            lines.append(cur); cur = w
        else:
            cur = test
    if cur: lines.append(cur)
    return lines or [text]

# ─── Draw Arabic text centered in rect ───────────────────────────────────────
def put_text(img_cv, text, x1, y1, x2, y2, bg_rgb):
    if not text.strip(): return img_cv
    bw, bh = x2-x1, y2-y1
    cx, cy = (x1+x2)/2, (y1+y2)/2
    lum = bg_rgb[0]*.299 + bg_rgb[1]*.587 + bg_rgb[2]*.114
    text_color = (10, 8, 5) if lum > 100 else (240, 235, 215)

    pil = Image.fromarray(cv2.cvtColor(img_cv, cv2.COLOR_BGR2RGB))
    draw = ImageDraw.Draw(pil)

    best_fs, best_lines, best_lh = 9, [text], 12
    for fs in range(int(bh * .52), 8, -1):
        font  = get_font(fs)
        lines = wrap_text(draw, text, font, bw * .84)
        lh    = fs * 1.36
        if len(lines) * lh <= bh * .85:
            best_fs, best_lines, best_lh = fs, lines, lh
            break

    font     = get_font(best_fs)
    total_h  = len(best_lines) * best_lh
    start_y  = cy - total_h/2 + best_lh * .22

    for i, line in enumerate(best_lines):
        bb = draw.textbbox((0,0), line, font=font)
        tx = cx - (bb[2]-bb[0])/2
        ty = start_y + i * best_lh
        draw.text((int(tx), int(ty)), line, font=font, fill=text_color)

    return cv2.cvtColor(np.array(pil), cv2.COLOR_RGB2BGR)

# ─── Inpainting methods ───────────────────────────────────────────────────────
def plain_fill(img_cv, x1, y1, x2, y2, bg_rgb):
    H, W = img_cv.shape[:2]
    x1,y1 = max(0,x1), max(0,y1)
    x2,y2 = min(W,x2), min(H,y2)
    if x2<=x1 or y2<=y1: return img_cv
    img_cv[y1:y2, x1:x2] = (bg_rgb[2], bg_rgb[1], bg_rgb[0])
    return img_cv

def inpaint_region(img_cv, x1, y1, x2, y2, bg_rgb):
    H, W = img_cv.shape[:2]
    x1,y1 = max(0,x1), max(0,y1)
    x2,y2 = min(W,x2), min(H,y2)
    if x2<=x1 or y2<=y1: return img_cv
    img_cv[y1+1:y2-1, x1+1:x2-1] = (bg_rgb[2], bg_rgb[1], bg_rgb[0])
    mask = np.zeros((H,W), dtype=np.uint8)
    mask[y1+1:y2-1, x1+1:x2-1] = 255
    return cv2.inpaint(img_cv, mask, 5, cv2.INPAINT_TELEA)

def contour_fill(img_cv, x1, y1, x2, y2, bg_rgb, thresh_val=190):
    """Fill exact bubble shape including oval tail using contour detection."""
    H, W = img_cv.shape[:2]
    x1,y1 = max(0,x1), max(0,y1)
    x2,y2 = min(W,x2), min(H,y2)
    bw, bh = x2-x1, y2-y1
    if bw<8 or bh<8: return img_cv

    crop = img_cv[y1:y2, x1:x2].copy()
    gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
    _, thresh = cv2.threshold(gray, thresh_val, 255, cv2.THRESH_BINARY)
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9,9))
    thresh = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, k)
    thresh = cv2.morphologyEx(thresh, cv2.MORPH_DILATE, k)

    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return inpaint_region(img_cv, x1, y1, x2, y2, bg_rgb)

    cnt = max(contours, key=cv2.contourArea)
    fill_mask = np.zeros((bh, bw), dtype=np.uint8)
    cv2.drawContours(fill_mask, [cnt], -1, 255, -1)

    crop_out = crop.copy()
    crop_out[fill_mask == 255] = (bg_rgb[2], bg_rgb[1], bg_rgb[0])
    img_cv[y1:y2, x1:x2] = crop_out

    full_mask = np.zeros((H,W), dtype=np.uint8)
    shifted = cnt + np.array([x1, y1])
    cv2.drawContours(full_mask, [shifted], -1, 255, -1)
    eroded = cv2.erode(full_mask, np.ones((5,5), np.uint8))
    border = full_mask.copy(); border[eroded == 255] = 0
    img_cv = cv2.inpaint(img_cv, border, 4, cv2.INPAINT_TELEA)

    return img_cv, fill_mask

def apply_bubble(img_cv, bubble, W, H):
    """
    Apply one bubble: erase English + write Arabic.
    bubble dict keys: x1,y1,x2,y2 (pixels), arabic, type, bg_color (optional)
    """
    x1 = max(0, min(W-1, int(bubble['x1'])))
    y1 = max(0, min(H-1, int(bubble['y1'])))
    x2 = max(0, min(W,   int(bubble['x2'])))
    y2 = max(0, min(H,   int(bubble['y2'])))
    if x2-x1 < 6 or y2-y1 < 6: return img_cv

    arabic = bubble.get('arabic', '')
    btype  = bubble.get('type', 'dialogue')

    # Determine background color
    if 'bg_color' in bubble:
        bg = tuple(bubble['bg_color'])
    else:
        bg = sample_bg(img_cv, x1, y1, x2, y2, btype)

    if btype == 'title':
        img_cv = plain_fill(img_cv, x1, y1, x2, y2, bg)
        if arabic: img_cv = put_text(img_cv, arabic, x1, y1, x2, y2, bg)

    elif btype == 'narration':
        img_cv = inpaint_region(img_cv, x1, y1, x2, y2, bg)
        if arabic: img_cv = put_text(img_cv, arabic, x1, y1, x2, y2, bg)

    elif btype == 'dialogue':
        result = contour_fill(img_cv, x1, y1, x2, y2, bg)
        if isinstance(result, tuple):
            img_cv, fill_mask = result
            if arabic:
                img_cv = place_text_in_body(img_cv, arabic, x1, y1, x2, y2, fill_mask, bg)
        else:
            img_cv = result
            if arabic: img_cv = put_text(img_cv, arabic, x1, y1, x2, y2, bg)

    else:  # sfx or unknown
        if arabic:
            img_cv = put_text(img_cv, arabic, x1, y1, x2, y2, bg)

    return img_cv

def place_text_in_body(img_cv, text, x1, y1, x2, y2, fill_mask, bg):
    """Place text in the widest (body) part of the bubble, not the tail."""
    bh = y2-y1
    row_widths = [(int(fill_mask[r].sum()//255), r) for r in range(bh)]
    row_widths.sort(reverse=True)
    wide_rows = sorted([r for _,r in row_widths[:max(1, bh//2)]])
    if not wide_rows:
        return put_text(img_cv, text, x1, y1, x2, y2, bg)

    body_y1 = y1 + wide_rows[0]
    body_y2 = y1 + wide_rows[-1]
    body_rows = fill_mask[wide_rows[0]:wide_rows[-1]+1]
    cols = np.where(body_rows.any(axis=0))[0]
    if not len(cols):
        return put_text(img_cv, text, x1, y1, x2, y2, bg)

    bx1 = x1 + int(cols[0])
    bx2 = x1 + int(cols[-1])
    pad = max(4, int((bx2-bx1)*.05))
    bx1 += pad; bx2 -= pad
    body_y1 += max(3, int((body_y2-body_y1)*.05))
    body_y2 -= max(3, int((body_y2-body_y1)*.05))
    if bx2 > bx1 and body_y2 > body_y1:
        return put_text(img_cv, text, bx1, body_y1, bx2, body_y2, bg)
    return put_text(img_cv, text, x1, y1, x2, y2, bg)

def sample_bg(img_cv, x1, y1, x2, y2, btype):
    """Sample dominant background color from bubble perimeter."""
    H, W = img_cv.shape[:2]
    bw, bh = x2-x1, y2-y1
    pts = []
    for t in np.linspace(.07, .93, 8):
        pts += [
            (int(x1+bw*t),    int(y1+bh*.06)),
            (int(x1+bw*t),    int(y1+bh*.94)),
            (int(x1+bw*.05),  int(y1+bh*t)),
            (int(x1+bw*.95),  int(y1+bh*t)),
        ]
    colors = []
    for px, py in pts:
        px = min(W-1, max(0, px)); py = min(H-1, max(0, py))
        b,g,r = [int(v) for v in img_cv[py,px,:3]]
        colors.append((r,g,b, r+g+b))
    colors.sort(key=lambda c: c[3], reverse=True)
    top = colors[:8]
    r = int(sum(c[0] for c in top)/len(top))
    g = int(sum(c[1] for c in top)/len(top))
    b = int(sum(c[2] for c in top)/len(top))
    # Force white for dialogue bubbles
    if btype == 'dialogue' and r > 180 and g > 180 and b > 180:
        return (255,255,255)
    return (r,g,b)

# ─── Claude API ───────────────────────────────────────────────────────────────
CLAUDE_SYSTEM = """أنت نظام تحليل ومعالجة كوميكس ومانغا متخصص.

مهمتك: تحليل الصورة المرفقة واستخراج كل فقاعات النص بإحداثيات بكسل دقيقة، ثم ترجمتها للعربية.

أجب بـ JSON خالص فقط — لا أي نص أو markdown قبله أو بعده:
{"bubbles":[{"id":1,"type":"dialogue","original":"...","arabic":"...","x1":120,"y1":45,"x2":380,"y2":190}]}

الحقول:
- type: "dialogue" = فقاعة حوار بيضاء بيضوية
         "narration" = صندوق سرد بيج/ذهبي اللون
         "title" = عنوان كبير على خلفية بيضاء
         "sfx" = مؤثر صوتي
- x1,y1: الزاوية العلوية اليسرى بالبكسل
- x2,y2: الزاوية السفلية اليمنى بالبكسل
- كن دقيقاً جداً في الإحداثيات — تحيط بمنطقة النص فقط

قواعد الترجمة:
- الحوار: طبيعي بأسلوب الشخصية
- السرد: أدبي وواضح
- المؤثرات: عرّبها (BANG=دوي، CRASH=ارتطام، SWOOSH=أزيز)
- العناوين: ترجم (PROLOGUE=المقدمة، CHAPTER=الفصل)
- الأسماء: اكتبها كما تُنطق بالعربية
- إذا لم يكن هناك نص إنجليزي أرجع: {"bubbles":[]}"""

def call_claude_api(image_path: str, api_key: str, img_w: int, img_h: int, retries=3) -> list:
    """Call Claude Vision API to detect and translate bubbles."""
    with open(image_path, 'rb') as f:
        img_data = f.read()

    ext = Path(image_path).suffix.lower()
    mime_map = {'.jpg':  'image/jpeg', '.jpeg': 'image/jpeg',
                '.png':  'image/png',  '.webp': 'image/webp'}
    mime = mime_map.get(ext, 'image/jpeg')

    # Resize if too large (Claude max ~5MB)
    pil = Image.open(image_path)
    if pil.width > 1600 or pil.height > 2200:
        pil.thumbnail((1600, 2200), Image.LANCZOS)
        import io
        buf = io.BytesIO()
        pil.save(buf, format='JPEG', quality=88)
        img_data = buf.getvalue()
        mime = 'image/jpeg'

    b64 = base64.b64encode(img_data).decode()

    payload = json.dumps({
        "model": CLAUDE_MODEL,
        "max_tokens": MAX_TOKENS,
        "system": CLAUDE_SYSTEM,
        "messages": [{
            "role": "user",
            "content": [
                {"type": "image",
                 "source": {"type": "base64", "media_type": mime, "data": b64}},
                {"type": "text",
                 "text": f"الصورة {img_w}×{img_h} بكسل. استخرج كل الفقاعات بإحداثيات بكسل دقيقة وترجم للعربية. JSON فقط."}
            ]
        }]
    }).encode()

    for attempt in range(retries):
        try:
            req = urllib.request.Request(
                'https://api.anthropic.com/v1/messages',
                data=payload,
                headers={
                    'Content-Type':      'application/json',
                    'x-api-key':         api_key,
                    'anthropic-version': '2023-06-01',
                },
                method='POST'
            )
            with urllib.request.urlopen(req, timeout=90) as resp:
                data = json.loads(resp.read())
                raw = data['content'][0]['text'].strip()
                # Strip possible markdown fences
                raw = re.sub(r'^```json\s*', '', raw)
                raw = re.sub(r'^```\s*',     '', raw)
                raw = re.sub(r'\s*```$',     '', raw).strip()
                # Extract JSON object
                m = re.search(r'\{[\s\S]*\}', raw)
                if not m:
                    return []
                parsed = json.loads(m.group())
                return parsed.get('bubbles', [])

        except urllib.error.HTTPError as e:
            body = e.read().decode()
            if e.code == 529 or 'overloaded' in body.lower():
                wait = 20 * (attempt + 1)
                print(f"    ⚠ API overloaded, waiting {wait}s...")
                time.sleep(wait)
            elif e.code == 400:
                print(f"    ✗ Bad request: {body[:200]}")
                return []
            else:
                raise
        except Exception as e:
            if attempt < retries - 1:
                time.sleep(5)
            else:
                raise

    return []

# ─── Process single image ─────────────────────────────────────────────────────
def process_image(input_path: str, output_path: str, api_key: str) -> bool:
    """Full pipeline: load → detect+translate → inpaint → save."""
    try:
        pil_src = Image.open(input_path).convert('RGB')
        img_cv  = cv2.cvtColor(np.array(pil_src), cv2.COLOR_RGB2BGR)
        H, W    = img_cv.shape[:2]

        # 1. Ask Claude to detect + translate
        bubbles = call_claude_api(input_path, api_key, W, H)

        if not bubbles:
            # No text found — copy original
            shutil.copy2(input_path, output_path)
            return True

        # 2. Apply each bubble
        for b in bubbles:
            img_cv = apply_bubble(img_cv, b, W, H)

        # 3. Save
        os.makedirs(os.path.dirname(output_path) or '.', exist_ok=True)
        cv2.imwrite(output_path, img_cv, [cv2.IMWRITE_JPEG_QUALITY, JPEG_QUALITY])
        return True

    except Exception as e:
        print(f"    ✗ Error: {e}")
        return False

# ─── Archive extraction ───────────────────────────────────────────────────────
def extract_archive(archive_path: str, dest_dir: str) -> list:
    """Extract CBZ/CBR/ZIP/RAR and return sorted image paths."""
    os.makedirs(dest_dir, exist_ok=True)
    ext = Path(archive_path).suffix.lower()

    if ext in ('.cbz', '.zip'):
        with zipfile.ZipFile(archive_path, 'r') as zf:
            zf.extractall(dest_dir)

    elif ext in ('.cbr', '.rar'):
        try:
            import rarfile
            with rarfile.RarFile(archive_path) as rf:
                rf.extractall(dest_dir)
        except ImportError:
            # Try patool as fallback
            try:
                import patoollib
                patoollib.extract_archive(archive_path, outdir=dest_dir)
            except:
                # Try system unrar
                ret = os.system(f'unrar x "{archive_path}" "{dest_dir}"')
                if ret != 0:
                    raise RuntimeError(
                        "CBR/RAR يحتاج: pip install rarfile\n"
                        "أو تثبيت unrar: apt install unrar"
                    )
    else:
        raise ValueError(f"نوع غير مدعوم: {ext}")

    # Collect all images recursively, sorted
    imgs = []
    for root, _, files in os.walk(dest_dir):
        for f in files:
            if Path(f).suffix.lower() in SUPPORTED_IMG:
                imgs.append(os.path.join(root, f))
    imgs.sort()
    return imgs

# ─── Batch processor ─────────────────────────────────────────────────────────
def repack_cbz(image_paths: list, output_cbz: str):
    """Pack translated images back into a CBZ."""
    with zipfile.ZipFile(output_cbz, 'w', zipfile.ZIP_DEFLATED) as zf:
        for p in sorted(image_paths):
            zf.write(p, os.path.basename(p))
    print(f"  📦 Packed → {output_cbz}")

def process_batch(inputs: list, output_dir: str, api_key: str,
                  workers: int = MAX_WORKERS, repack: bool = True):
    """
    Process a list of image paths in parallel.
    inputs: list of image file paths
    """
    os.makedirs(output_dir, exist_ok=True)
    results  = {}
    total    = len(inputs)
    done     = 0

    print(f"\n🚀 بدء الترجمة — {total} صفحة | {workers} عمال متوازيين\n{'─'*50}")

    def job(img_path):
        name   = Path(img_path).stem + '_ar.jpg'
        out    = os.path.join(output_dir, name)
        ok     = process_image(img_path, out, api_key)
        return img_path, out, ok

    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(job, p): p for p in inputs}
        for fut in as_completed(futures):
            src, out, ok = fut.result()
            done += 1
            status = '✓' if ok else '✗'
            print(f"  [{done:>3}/{total}] {status} {Path(src).name}")
            results[src] = out if ok else None

    ok_count  = sum(1 for v in results.values() if v)
    fail_count = total - ok_count
    print(f"\n{'─'*50}")
    print(f"✅ نجح: {ok_count}  |  ❌ فشل: {fail_count}")

    return [v for v in results.values() if v]

# ─── Main entry ───────────────────────────────────────────────────────────────
def main():
    ap = argparse.ArgumentParser(
        description='AutoScanlate AR — مترجم كوميكس/مانغا تلقائي'
    )
    ap.add_argument('--input',   '-i', required=True,
                    help='مسار الملف أو المجلد (صورة/CBZ/CBR/ZIP أو مجلد)')
    ap.add_argument('--output',  '-o', default='',
                    help='مجلد الإخراج (افتراضي: input_ar/)')
    ap.add_argument('--api_key', '-k', default='',
                    help='مفتاح Anthropic API (أو ANTHROPIC_API_KEY)')
    ap.add_argument('--workers', '-w', type=int, default=MAX_WORKERS,
                    help=f'عدد الصفحات المتوازية (افتراضي: {MAX_WORKERS})')
    ap.add_argument('--repack',  '-r', action='store_true', default=True,
                    help='إعادة تعبئة كـ CBZ بعد الترجمة')
    ap.add_argument('--quality', '-q', type=int, default=JPEG_QUALITY,
                    help=f'جودة JPEG (افتراضي: {JPEG_QUALITY})')
    args = ap.parse_args()

    # API key
    api_key = args.api_key or os.environ.get('ANTHROPIC_API_KEY', '')
    if not api_key:
        print("❌ مفتاح API مطلوب: --api_key sk-ant-... أو export ANTHROPIC_API_KEY=...")
        sys.exit(1)

    global JPEG_QUALITY
    JPEG_QUALITY = args.quality

    input_path  = args.input
    output_dir  = args.output or (Path(input_path).stem + '_ar')

    # ── Determine input type ──
    images_to_process = []
    archive_mode      = False
    archive_stem      = ''

    p = Path(input_path)

    if p.is_dir():
        # Folder of images
        for f in sorted(p.rglob('*')):
            if f.suffix.lower() in SUPPORTED_IMG:
                images_to_process.append(str(f))
        print(f"📁 مجلد: {len(images_to_process)} صورة")

    elif p.suffix.lower() in ('.cbz', '.cbr', '.zip', '.rar'):
        # Archive
        archive_mode = True
        archive_stem = p.stem
        extract_dir  = os.path.join(output_dir, '_extracted')
        print(f"📦 فك ضغط: {p.name} ...")
        images_to_process = extract_archive(str(p), extract_dir)
        print(f"   → {len(images_to_process)} صورة")

    elif p.suffix.lower() in SUPPORTED_IMG:
        # Single image
        images_to_process = [str(p)]
        print(f"🖼 صورة واحدة: {p.name}")

    else:
        print(f"❌ نوع غير مدعوم: {p.suffix}")
        sys.exit(1)

    if not images_to_process:
        print("❌ لم يُعثر على صور")
        sys.exit(1)

    # Cap at 100 per batch (as requested)
    if len(images_to_process) > 100:
        print(f"⚠ {len(images_to_process)} صورة — سيُعالج أول 100 فقط في هذه الدفعة")
        images_to_process = images_to_process[:100]

    # ── Process ──
    translated_dir = os.path.join(output_dir, 'pages')
    translated     = process_batch(images_to_process, translated_dir, api_key, args.workers)

    # ── Repack to CBZ ──
    if archive_mode and args.repack and translated:
        cbz_out = os.path.join(output_dir, archive_stem + '_ar.cbz')
        repack_cbz(translated, cbz_out)
        print(f"\n✨ الملف الجاهز: {cbz_out}")
    else:
        print(f"\n✨ الصور الجاهزة في: {translated_dir}/")

if __name__ == '__main__':
    main()
